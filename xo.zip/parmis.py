#x is player o is computer
import tkinter
import random
from tkinter import messagebox
class Game:
    Buttons=[]
    def __init__(self):
        self.state=[" " for i in range(1,10)]
        self.turn=random.choice(['x','o'])
        self.window(self.turn)
        if self.turn=='o':
            self.computer_move()
        self.root.mainloop()



    def finishthegame(self,letter):
        tkinter.messagebox.showinfo(title='game resault',message=f'{letter if (letter=="x" or letter=="o") else "no one"} won!')
        self.reset_game()
    def check_state(self,state):

        win_pos=[[0,1,2],[0,3,6],[2,5,8],[6,7,8],[0,4,8],[2,4,6],[3,4,5],[1,4,7]]
        for i in win_pos:
            if state[i[0]]==state[i[1]] and state[i[1]]==state[i[2]] and state[i[2]]!=" ":
                return state[i[0]]
        return 'Tie' if state.count(" ")==0 else 'not finished'
    def ai(self):
        for i in range(0,9):
            cloned_state=self.state.copy()
            if cloned_state[i]==" ":
                cloned_state[i]='o'
                tmp = self.check_state(cloned_state)

                if tmp == 'o' :
                    print(cloned_state , tmp )
                    return i
        for i in range(0,9):
            cloned_state=self.state.copy()
            if cloned_state[i]==" ":
                cloned_state[i]='x'
                if self.check_state(cloned_state)== 'x':
                    return i

        i=random.choice([0,2,6,8])
        if self.state[i]==" ":
             return i
        if self.state[4] == " ":
            return i

        i=random.choice([1,3,5,7])
        if self.state[i]==" ":
             return i

    def computer_move(self):
        ai=self.ai()
        self.state[ai]='o'
        self.Buttons[ai].config(text="o",bg="red")
        resault=self.check_state(self.state)
        if resault=='o':
            self.root.update()
            self.finishthegame("o")
        elif resault=="Tie":
            self.finishthegame(None)

    def clickOnBtn(self,button_index):
        if self.state[button_index]==" ":
            self.state[button_index] ="x"
            self.Buttons[button_index].config(text="x",bg="blue")
            resault=self.check_state(self.state)
            print(resault , self.state)
            if resault=="x":
                self.root.update()
                self.finishthegame("x")

            elif resault=='Tie':
                self.finishthegame(None)
            else:
                self.computer_move()

    def window(self,first_letter):
        self.root=tkinter.Tk()
        self.root.title("Tic Tac Toe")
        self.root.geometry("400x400")
        self.root.resizable(0,0)
        self.top_frame=tkinter.Frame(self.root)
        self.top_frame.pack()

        self.Button_frame=tkinter.Frame(self.root)
        self.Button_frame.pack()
        for rows in range(0,3):
            for columns in range(0,3):
                btn=tkinter.Button(self.Button_frame,text=rows*3+columns,bg='white',fg="black",command=lambda x=rows*3+columns : self.clickOnBtn(x))
                btn.grid(row=rows,column=columns,ipadx=30,ipady=30)
                self.Buttons.append(btn)
        btn_reset=tkinter.Button(self.root,text="reset the game",command=self.reset_game)
        btn_quit=tkinter.Button(self.root,text='Quit',bg='white',command=self.root.destroy)
        self.status_lable=tkinter.Label(self.top_frame,text=f"starting letter:{first_letter}")
        self.status_lable.pack()
        btn_quit.pack()
        btn_reset.pack()

    def reset_game(self):
        self.root.destroy()
        self.Buttons = []
        self.__init__()



win=Game()
